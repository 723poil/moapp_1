package com.teachingrecycle.testcamera2

import android.content.ContentResolver
import android.content.Context
import android.content.pm.ApplicationInfo
import android.graphics.Bitmap
import android.graphics.ImageDecoder
import android.net.Uri
import android.os.Environment
import android.provider.MediaStore
import android.util.Log
import okhttp3.MediaType
import okhttp3.MultipartBody
import okhttp3.RequestBody
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.io.File
import java.io.FileOutputStream
import java.io.IOException

object UploadRepository {
    private val api: Api

    init {
        val retrofit = Retrofit.Builder()
            .baseUrl("http://34.64.115.128")
            .addConverterFactory(GsonConverterFactory.create())
            .build()
        api = retrofit.create(Api::class.java)
    }

    fun postImg_camera(photoUri: Uri, fileName: String, context: Context) {
        val filePath = context.applicationInfo.dataDir + File.separator + System.currentTimeMillis() + "." + fileName.substring(fileName.lastIndexOf(".") +1)
        val file = File(filePath)
        Log.d("lsh", "${filePath}, ${file.toString()}")

        try {
            val inputStream = context.contentResolver.openInputStream(photoUri)
            val outputStream = FileOutputStream(file)

            inputStream.use { input ->
                input?.copyTo(outputStream)
            }

            outputStream.close()
            inputStream?.close()
        } catch (err: IOException) {
            Log.d("lsh", "in try catch : ${err.toString()}")
        }

        val abFile = File(file.absolutePath)
        val requestFile = RequestBody.create(MediaType.parse("multipart/form-data"), abFile)
        val body = MultipartBody.Part.createFormData("file", abFile.name, requestFile)

        api.postImg(body).enqueue(object : Callback<ResponseUpload> {
            override fun onResponse(
                call: Call<ResponseUpload>,
                response: Response<ResponseUpload>
            ) {
                Log.d("lsh", response.body().toString())
            }

            override fun onFailure(call: Call<ResponseUpload>, t: Throwable) {
                Log.d("lsh", "${call.toString()}, ${t.toString()}")
            }
        })
    }
    fun postImg_gallery(bitmap: Bitmap, context: Context) {
        val filePath = context.applicationInfo.dataDir + File.separator + System.currentTimeMillis() + ".jpg"
        val file = File(filePath)
        Log.d("lsh", "${filePath}, ${file.toString()}")

        try {
            val outputStream = FileOutputStream(file)
            bitmap.compress(Bitmap.CompressFormat.JPEG, 100, outputStream)

            outputStream.close()
        } catch (err: IOException) {
            Log.d("lsh", "in try catch : ${err.toString()}")
        }

        val abFile = File(file.absolutePath)
        val requestFile = RequestBody.create(MediaType.parse("multipart/form-data"), abFile)
        val body = MultipartBody.Part.createFormData("file", abFile.name, requestFile)

        api.postImg(body).enqueue(object : Callback<ResponseUpload> {
            override fun onResponse(
                call: Call<ResponseUpload>,
                response: Response<ResponseUpload>
            ) {
                Log.d("lsh", response.body().toString())
            }

            override fun onFailure(call: Call<ResponseUpload>, t: Throwable) {
                Log.d("lsh", "${call.toString()}, ${t.toString()}")
            }
        })
    }
}