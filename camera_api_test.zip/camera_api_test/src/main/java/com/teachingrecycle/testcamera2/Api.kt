package com.teachingrecycle.testcamera2

import okhttp3.MultipartBody
import retrofit2.Call
import retrofit2.http.*

interface Api {
    @Multipart
    @POST("/image-upload/classification")
    fun postImg(@Part photo: MultipartBody.Part): Call<ResponseClassification>
}